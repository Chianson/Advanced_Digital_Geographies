// JavaScript File
"use strict";
(function () {
    window.onload = function() {
        mapboxgl.accessToken = 'pk.eyJ1IjoiY2hpYW5zb24iLCJhIjoiY2pkeXVkM3pwMnZ0bDMydDM5ZTdvMnFrMSJ9.tkK3NgjXaLtmcilvC4RH3Q';
            var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v10',
            center: [-122.3321, 47.6062],
            zoom: 9
        });
    map.on("load", function() {
        map.addSource('homeles_data', {
          type: 'csv',
          data: './homeless_data.csv'
        })
    })   
    }
})()